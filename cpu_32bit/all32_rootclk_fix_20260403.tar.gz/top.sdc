# clock
create_clock -name clk -period 2.0 [get_ports clk_pin] ;# -waveform {0.25 1.50}

set_clock_latency 1.0 [get_clocks clk ]

# input/output delays
#              actually inputs are generated on the falling edge with 0 delay
#set_input_delay  -clock clk 1.0 [all_inputs]
set_input_delay  -clock clk 1.0 [remove_from_collection [all_inputs] [get_ports clk_pin]]
set_output_delay -clock clk 1.0 [all_outputs]

# multicycle paths

# for setup
set_multicycle_path 2 -through U_CORE/DP/ALU/sub_*/Z*
set_multicycle_path 1 -through U_CORE/DP/ALU/srl_*/Z*
set_multicycle_path 1 -through U_CORE/DP/ALU/sll_*/Z*
set_multicycle_path 2 -through U_CORE/DP/ALU/mul_*/Z*
set_multicycle_path 3 -through U_CORE/DP/ALU/div_*/QUOTIENT*
# for hold
set_multicycle_path 1 -through U_CORE/DP/ALU/sub_*/Z* -hold
set_multicycle_path 0 -through U_CORE/DP/ALU/srl_*/Z* -hold
set_multicycle_path 0 -through U_CORE/DP/ALU/sll_*/Z* -hold
set_multicycle_path 1 -through U_CORE/DP/ALU/mul_*/Z* -hold
set_multicycle_path 2 -through U_CORE/DP/ALU/div_*/QUOTIENT* -hold

