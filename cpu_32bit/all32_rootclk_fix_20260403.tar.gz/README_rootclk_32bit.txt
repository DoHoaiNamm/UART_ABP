This package updates the minimum-change 32-bit RTL with:
1) cpu_config.vh: data_width changed from 16 to 32
2) io_wrapper.v: din/dout pad instances expanded from [15:0] to [31:0]
3) io_wrapper.v: inserted BUFX8 root clock buffer:
   PADI set_dont_touch_in_clk -> clk_int_tmp
   BUFX8 set_dont_touch_root_clk_buf -> clk_int
4) top.v: added `include "cpu_config.vh" for standalone compilation

The top module name remains cpu_16bit_top.
The core module name remains cpu_16bit.
The synthesizable RAM path remains unchanged.
